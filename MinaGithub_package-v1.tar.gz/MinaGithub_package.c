#include <stdio.h>

int main() {
    printf("\n*****************************\n");
    printf("* Hello Mina GitHub Package *");
    printf("\n*****************************\n");

    return 0;
}
